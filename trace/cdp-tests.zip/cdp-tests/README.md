# CDP-Tests

**Notice: For 2022 students, please use the `peri` branch.**

This repository is for the Computer Design and Practice course of Harbin Institute of Technology, Shenzhen. 

The main branch is a stable release used in 2021 summer semester. It does not offer peripheral support. 

The project is inspired by NEMU (https://github.com/OpenXiangShan/NEMU). Thank [Zihao Yu](https://github.com/sashimi-yzh) for developing the NEMU project. 
